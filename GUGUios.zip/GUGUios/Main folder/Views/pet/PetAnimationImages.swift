import SwiftUI

struct PetAnimationImages {
    static let happy1 = Image("happy1")
    static let happy2 = Image("happy1")
    
    static let ideal1 = Image("ideal1")
    static let ideal2 = Image("ideal1")
    
    static let play1 = Image("play1")
    static let play2 = Image("play1")
    
    static let sleepy1 = Image("sleepy1")
    static let sleepy2 = Image("sleepy1")
    
    static let hungry1 = Image("hungry1")
    static let hungry2 = Image("hungry1")
    
    static let passedout1 = Image("passout1")
    static let passedout2 = Image("passout1")
}
