//
//  SwiftDataRewardRepository.swift
//  GUGUios
//
//  SwiftData repository for Reward and Achievement management
//

import Foundation
import SwiftData
import SwiftUI
import Combine
import os.log

class SwiftDataRewardRepository: ObservableObject {
    private let modelContext: ModelContext
    private let logger = Logger(subsystem: "GUGUios", category: "SwiftDataRewardRepository")
    
    @Published private(set) var achievements: [Achievement] = []
    @Published private(set) var streaks: [UUID: GoalStreak] = [:]
    @Published private(set) var isLoading = false
    
    init(modelContext: ModelContext) {
        self.modelContext = modelContext
        Task {
            await loadData()
        }
    }
    
    // MARK: - Data Loading
    
    func loadData() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            try await loadAchievements()
            try await loadStreaks()
            logger.info("Successfully loaded achievements and streaks from SwiftData")
        } catch {
            logger.error("Failed to load data: \(error.localizedDescription)")
        }
    }
    
    private func loadAchievements() async throws {
        let descriptor = FetchDescriptor<SDAchievement>(
            sortBy: [SortDescriptor(\SDAchievement.dateEarned, order: .reverse)]
        )
        
        let sdAchievements = try modelContext.fetch(descriptor)
        achievements = sdAchievements.map { $0.toLegacyAchievement() }
        
        // If no achievements exist, create default ones
        if achievements.isEmpty {
            await createDefaultAchievements()
        }
    }
    
    private func loadStreaks() async throws {
        let descriptor = FetchDescriptor<SDGoalStreak>()
        let sdStreaks = try modelContext.fetch(descriptor)
        
        streaks = [:]
        for sdStreak in sdStreaks {
            streaks[sdStreak.goalId] = sdStreak.toLegacyGoalStreak()
        }
    }
    
    private func createDefaultAchievements() async {
        let defaultAchievements = [
            Achievement(type: .waterStreak, level: .bronze),
            Achievement(type: .mealStreak, level: .bronze),
            Achievement(type: .breakStreak, level: .bronze),
            Achievement(type: .petCare, level: .bronze),
            Achievement(type: .consistency, level: .bronze)
        ]
        
        do {
            for achievement in defaultAchievements {
                let sdAchievement = SDAchievement.fromLegacyAchievement(achievement)
                modelContext.insert(sdAchievement)
            }
            try modelContext.save()
            achievements = defaultAchievements
            logger.info("Created default achievements")
        } catch {
            logger.error("Failed to create default achievements: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Achievement Management
    
    func saveAchievements(_ achievements: [Achievement]) async throws {
        // Clear existing achievements
        let existingDescriptor = FetchDescriptor<SDAchievement>()
        let existingAchievements = try modelContext.fetch(existingDescriptor)
        
        for existing in existingAchievements {
            modelContext.delete(existing)
        }
        
        // Save new achievements
        for achievement in achievements {
            let sdAchievement = SDAchievement.fromLegacyAchievement(achievement)
            modelContext.insert(sdAchievement)
        }
        
        try modelContext.save()
        self.achievements = achievements
        logger.info("Saved \(achievements.count) achievements to SwiftData")
    }
    
    func addAchievement(_ achievement: Achievement) async throws {
        guard !achievements.contains(where: { $0.id == achievement.id }) else { return }
        
        let sdAchievement = SDAchievement.fromLegacyAchievement(achievement)
        modelContext.insert(sdAchievement)
        try modelContext.save()
        
        achievements.append(achievement)
        logger.info("Added new achievement: \(achievement.type.rawValue)")
    }
    
    func updateAchievement(_ achievement: Achievement) async throws {
        // Find existing SwiftData achievement
        let predicate = #Predicate<SDAchievement> { $0.id == achievement.id }
        let descriptor = FetchDescriptor(predicate: predicate)
        
        if let existingSD = try modelContext.fetch(descriptor).first {
            // Update the SwiftData model
            existingSD.progress = achievement.progress
            existingSD.isCompleted = achievement.isCompleted
            existingSD.streakCount = achievement.streakCount
            existingSD.targetValue = achievement.targetValue
            existingSD.updatedAt = Date()
            
            try modelContext.save()
            
            // Update local array
            if let index = achievements.firstIndex(where: { $0.id == achievement.id }) {
                achievements[index] = achievement
            }
            
            logger.info("Updated achievement: \(achievement.type.rawValue)")
        }
    }
    
    func getAchievements(ofType type: AchievementType) -> [Achievement] {
        return achievements.filter { $0.type == type }
    }
    
    func getAchievements(ofLevel level: AchievementLevel) -> [Achievement] {
        return achievements.filter { $0.level == level }
    }
    
    func getRecentAchievements(days: Int = 7) -> [Achievement] {
        let cutoffDate = Calendar.current.date(byAdding: .day, value: -days, to: Date()) ?? Date()
        return achievements.filter { $0.dateEarned >= cutoffDate }
    }
    
    // MARK: - Streak Management
    
    func saveStreaks(_ streaks: [UUID: GoalStreak]) async throws {
        // Clear existing streaks
        let existingDescriptor = FetchDescriptor<SDGoalStreak>()
        let existingStreaks = try modelContext.fetch(existingDescriptor)
        
        for existing in existingStreaks {
            modelContext.delete(existing)
        }
        
        // Save new streaks
        for (goalId, streak) in streaks {
            let sdStreak = SDGoalStreak.fromLegacyGoalStreak(streak, goalId: goalId)
            modelContext.insert(sdStreak)
        }
        
        try modelContext.save()
        self.streaks = streaks
        logger.info("Saved \(streaks.count) streaks to SwiftData")
    }
    
    func updateStreak(for goalId: UUID, streak: GoalStreak) async throws {
        // Find existing SwiftData streak
        let predicate = #Predicate<SDGoalStreak> { $0.goalId == goalId }
        let descriptor = FetchDescriptor(predicate: predicate)
        
        if let existingSD = try modelContext.fetch(descriptor).first {
            // Update existing streak
            existingSD.updateStreak(
                current: streak.currentStreak,
                best: streak.bestStreak,
                lastCompletion: streak.lastCompletionDate,
                total: streak.totalCompletions,
                perfectWeeks: streak.perfectWeeks
            )
        } else {
            // Create new streak
            let sdStreak = SDGoalStreak.fromLegacyGoalStreak(streak, goalId: goalId)
            modelContext.insert(sdStreak)
        }
        
        try modelContext.save()
        streaks[goalId] = streak
        logger.info("Updated streak for goal: \(goalId)")
    }
    
    func getStreak(for goalId: UUID) -> GoalStreak? {
        return streaks[goalId]
    }
    
    func getAllStreaks() -> [UUID: GoalStreak] {
        return streaks
    }
    
    func ensureStreak(for goalId: UUID) async throws {
        if streaks[goalId] == nil {
            let newStreak = GoalStreak()
            try await updateStreak(for: goalId, streak: newStreak)
        }
    }
    
    // MARK: - Statistics and Analytics
    
    func getTotalAchievements() -> Int {
        return achievements.count
    }
    
    func getAchievementsByLevel() -> [AchievementLevel: Int] {
        var levelCounts: [AchievementLevel: Int] = [:]
        
        for achievement in achievements {
            levelCounts[achievement.level, default: 0] += 1
        }
        
        return levelCounts
    }
    
    func getAchievementsByType() -> [AchievementType: Int] {
        var typeCounts: [AchievementType: Int] = [:]
        
        for achievement in achievements {
            typeCounts[achievement.type, default: 0] += 1
        }
        
        return typeCounts
    }
    
    func getCurrentStreakLevel(for goalId: UUID) -> Int {
        return streaks[goalId]?.currentStreak ?? 0
    }
    
    func getBestStreakLevel(for goalId: UUID) -> Int {
        return streaks[goalId]?.bestStreak ?? 0
    }
    
    
    // MARK: - Cleanup and Maintenance
    
    func cleanupOldAchievements(olderThan days: Int = 365) async throws {
        let cutoffDate = Calendar.current.date(byAdding: .day, value: -days, to: Date()) ?? Date()
        
        let predicate = #Predicate<SDAchievement> { $0.dateEarned < cutoffDate }
        let descriptor = FetchDescriptor(predicate: predicate)
        
        let oldAchievements = try modelContext.fetch(descriptor)
        
        for achievement in oldAchievements {
            modelContext.delete(achievement)
        }
        
        if !oldAchievements.isEmpty {
            try modelContext.save()
            // Reload data to update local arrays
            try await loadAchievements()
            logger.info("Cleaned up \(oldAchievements.count) old achievements")
        }
    }
    
    func resetAllStreaks() async throws {
        let descriptor = FetchDescriptor<SDGoalStreak>()
        let allStreaks = try modelContext.fetch(descriptor)
        
        for sdStreak in allStreaks {
            sdStreak.currentStreak = 0
            sdStreak.lastCompletionDate = nil
            sdStreak.updatedAt = Date()
        }
        
        try modelContext.save()
        
        // Update local streaks
        for goalId in streaks.keys {
            var streak = streaks[goalId]!
            streak.currentStreak = 0
            streak.lastCompletionDate = nil
            streaks[goalId] = streak
        }
        
        logger.info("Reset all streaks")
    }
    
    // MARK: - Error Handling
    
    enum RepositoryError: Error, LocalizedError {
        case achievementNotFound
        case streakNotFound
        case migrationFailed(String)
        case saveError(String)
        
        var errorDescription: String? {
            switch self {
            case .achievementNotFound:
                return "Achievement not found"
            case .streakNotFound:
                return "Streak not found"
            case .migrationFailed(let message):
                return "Migration failed: \(message)"
            case .saveError(let message):
                return "Save error: \(message)"
            }
        }
    }
}

// MARK: - Legacy Compatibility

extension SwiftDataRewardRepository {
    func toLegacyAchievements() -> [Achievement] {
        return achievements
    }
    
    func toLegacyStreaks() -> [UUID: GoalStreak] {
        return streaks
    }
}