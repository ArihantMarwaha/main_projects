//
//  SDAchievement.swift
//  GUGUios
//
//  SwiftData model for Achievement persistence
//

import Foundation
import SwiftData
import SwiftUI

@Model
class SDAchievement {
    @Attribute(.unique) var id: UUID
    var typeRawValue: String
    var levelRawValue: Int
    var dateEarned: Date
    var progress: Double
    var isCompleted: Bool
    var streakCount: Int
    var targetValue: Int
    var createdAt: Date
    var updatedAt: Date
    
    init(id: UUID = UUID(),
         type: AchievementType,
         level: AchievementLevel,
         dateEarned: Date = Date(),
         progress: Double = 0.0,
         isCompleted: Bool = false,
         streakCount: Int = 0,
         targetValue: Int = 0) {
        self.id = id
        self.typeRawValue = type.rawValue
        self.levelRawValue = level.rawValue
        self.dateEarned = dateEarned
        self.progress = progress
        self.isCompleted = isCompleted
        self.streakCount = streakCount
        self.targetValue = targetValue
        self.createdAt = Date()
        self.updatedAt = Date()
    }
    
    // Computed properties for type-safe access
    var type: AchievementType {
        get { AchievementType(rawValue: typeRawValue) ?? .consistency }
        set { typeRawValue = newValue.rawValue }
    }
    
    var level: AchievementLevel {
        get { AchievementLevel(rawValue: levelRawValue) ?? .bronze }
        set { levelRawValue = newValue.rawValue }
    }
    
    // Convert to legacy Achievement model for compatibility
    func toLegacyAchievement() -> Achievement {
        return Achievement(
            type: self.type,
            level: self.level,
            dateEarned: self.dateEarned,
            progress: self.progress,
            isCompleted: self.isCompleted,
            streakCount: self.streakCount,
            targetValue: self.targetValue
        )
    }
    
    // Create from legacy Achievement model
    static func fromLegacyAchievement(_ achievement: Achievement) -> SDAchievement {
        return SDAchievement(
            id: achievement.id,
            type: achievement.type,
            level: achievement.level,
            dateEarned: achievement.dateEarned,
            progress: achievement.progress,
            isCompleted: achievement.isCompleted,
            streakCount: achievement.streakCount,
            targetValue: achievement.targetValue
        )
    }
    
    // Update progress and completion status
    func updateProgress(newProgress: Double) {
        progress = min(1.0, max(0.0, newProgress))
        isCompleted = progress >= 1.0
        updatedAt = Date()
    }
}